import { LightningElement } from 'lwc';
import ACCOUNT_NAME from '@salesforce/schema/Account.Name';
import ACCOUNT_TYPE from '@salesforce/schema/Account.Type';
import ACCOUNT_OWNER from '@salesforce/schema/Account.OwnerId';
import SLA_FIELD from '@salesforce/schema/Account.SLA__c';
import { CurrentPageReference, NavigationMixin } from 'lightning/navigation';

export default class DemoViewForm extends NavigationMixin(LightningElement) {

    selectedFields = [ACCOUNT_NAME, ACCOUNT_TYPE, ACCOUNT_OWNER, SLA_FIELD];
    accountId = "0012v000030rPdkAAE"

    handleCancel(event) {
        console.log('cancelled button clicked');
        
/*         this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId : this.accountId,
                objectApiName: 'Account',
                actionName: 'view',
            },
        });   */
        this.onOpenAccountClick();
    }
    onOpenAccountClick() {
        console.log('in openAccount')
        this.invokeWorkspaceAPI('isConsoleNavigation').then(isConsole => {
          if (isConsole) {
            this.invokeWorkspaceAPI('getFocusedTabInfo').then(focusedTab => {
                console.log(focusedTab.tabId)
              this.invokeWorkspaceAPI('closeTab', {
                tabId: focusedTab.tabId,
              }).then(tabId1 => {
                //console.log(tabId1);
              }).catch(error=>{
                  console.log(error)
              });
            });
          }
        });
    }
     
    invokeWorkspaceAPI(methodName, methodArgs) {
        return new Promise((resolve, reject) => {
          const apiEvent = new CustomEvent("internalapievent", {
            bubbles: true,
            composed: true,
            cancelable: false,
            detail: {
              category: "workspaceAPI",
              methodName: methodName,
              methodArgs: methodArgs,
              callback: (err, response) => {
                if (err) {
                    return reject(err);
                } else {
                    return resolve(response);
                }
              }
            }
          });
     
          window.dispatchEvent(apiEvent);
        });
    }

}